# アバターExperssions menuで色変更

購入したシィちゃん用浴衣衣装に複数の色、模様があったがExpressions menuで使うにはこちら側で設定しなきゃいけないっぽかったので、調べた。

[https://www.youtube.com/watch?v=w1ZzU8J9_i4](https://www.youtube.com/watch?v=w1ZzU8J9_i4)

これを参考にやる

1. Radial Inventory System V4のダウンロード
[https://booth.pm/ja/items/2278448](https://booth.pm/ja/items/2278448)
2. RISV4をunityプロジェクトにインポートする
3. アニメーションを作る
    1. Window>Animation>AnimationでAnimationウィンドウを開く
    2. 「Create」して新しいアニメーション(.anim)を作る
    3. 録画ボタンを押してから、作成したいアニメーション（今回は着せ替え）ができるように衣装をunityエディタ上で着せ替えたり、マテリアルを変えたりする